const menu = document.querySelector('.menu-toggle');
const nav = document.querySelector('nav');
menu?.addEventListener('click', () => {
  nav.style.display = nav.style.display === 'flex' ? 'none' : 'flex';
});
document.querySelectorAll('nav a').forEach(a => a.addEventListener('click', () => {
  if (innerWidth <= 800) nav.style.display = 'none';
}));
document.getElementById('year').textContent = new Date().getFullYear();

// Application form
document.getElementById('applyForm').addEventListener('submit', e => {
  e.preventDefault();
  const f = new FormData(e.currentTarget);
  const subject = encodeURIComponent('Prime Vixen Agency Model Application — ' + f.get('name'));
  const body = encodeURIComponent(
    `Name: ${f.get('name')}\n` +
    `Email: ${f.get('email')}\n` +
    `Phone: ${f.get('phone')}\n` +
    `Age: ${f.get('age')}\n` +
    `Gender: ${f.get('gender')}\n` +
    `Location: ${f.get('location')}\n` +
    `Height: ${f.get('height') || 'Not provided'}\n` +
    `Social: ${f.get('social') || 'Not provided'}\n\n` +
    `Experience & Goals:\n${f.get('experience')}\n\n` +
    `---\nPlease attach the headshot, full body, and any additional photos you selected before sending this email.`
  );
  window.location.href = `mailto:srstrategicventures2026@gmail.com?subject=${subject}&body=${body}`;
  alert('Your application email has been prepared. Please attach the photos you selected (headshot, full body, and any additional images) before sending.');
});

// Review form
document.getElementById('reviewForm').addEventListener('submit', e => {
  e.preventDefault();
  const f = new FormData(e.currentTarget);
  const stars = '★'.repeat(Number(f.get('rating'))) + '☆'.repeat(5 - Number(f.get('rating')));
  const subject = encodeURIComponent('Prime Vixen Agency Review from ' + f.get('reviewer'));
  const body = encodeURIComponent(
    `Reviewer: ${f.get('reviewer')}\n` +
    `Rating: ${stars} (${f.get('rating')}/5)\n\n` +
    `Review:\n${f.get('review')}`
  );
  window.location.href = `mailto:srstrategicventures2026@gmail.com?subject=${subject}&body=${body}`;
  alert('Thank you! Your review email has been prepared. The agency will review it before it appears on the site.');
});
